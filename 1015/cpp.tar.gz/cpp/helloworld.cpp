#include<iostream>
using namespace std;
int x;
int main()
{
	cout<<"hello world";
	x=10;
	cout<<"x="<<x;
	x=20;
	cout<<"x="<<x;

}
