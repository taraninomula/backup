print('please enter text')
x=input()
print('text',x)
print('type',type(x))
